#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <errno.h>
#define MAX 1024
#define PORT 8080 
#define SA struct sockaddr
#include"connexion_capteur.h"


int main() 
{ 
	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 

	// creation et vérification de la socket 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("création de la socket est échouée...\n"); 
		exit(0); 
	} 
	else
		printf("le socket à été bien crée..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// définir IPV4, l'adresse, le port  
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

	//permet d'attacher le socket par un port et une adresse 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("bind est échoué...\n"); 
		exit(0); 
	} 
	else
		printf("bind succès..\n"); 

	// reception des connexions du client 
	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen échoué...\n"); 
		exit(0); 
	} 
	else
		printf("Serveur est en écoute..\n"); 
	len = sizeof(cli); 

	// accepter les connexions du client 
	connfd = accept(sockfd, (SA*)&cli, &len); 
	if (connfd < 0) { 
		printf("serveur acccept échoué...\n"); 
		exit(0); 
	} 
	else
		printf("serveur acccépte le client...\n"); 

	// fonction d'envoie et de réception des message avec le client 
	func(connfd); 

	// fermeture de la socket 
	close(sockfd); 
} 

