#ifndef __CUSTOM_H_
#define __CUSTOM_H_
#include <stdlib.h>
void func(int);
#endif /* ifndef __CUSTOM_H_ */
