#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#define MAX 1024
#define PORT 8080 
#define SA struct sockaddr 
#include"interface.h" 



int main() 
{ 
	int sockfd, connfd; 
	struct sockaddr_in servaddr, cli; 

	// création et vérification de la socket
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket est échouée\n"); 
		exit(0); 
	} 
	else
		printf("Socket à été bien créé..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// définir IPV4, l'adresse, le port  
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	servaddr.sin_port = htons(PORT); 

	// connecter la socket du client au serveur 
	if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
		printf("connexion au serveur est échoué...\n"); 
		exit(0); 
	} 
	else
		printf("connecté au serveur..\n"); 

	// fonction d'envoie et de réception de message 
	func(sockfd); 

	// fermeture de la socket 
	close(sockfd); 
} 

