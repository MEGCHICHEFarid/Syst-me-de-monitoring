#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <fcntl.h>
#define MAX 1024
#define PORT 8080 
#define SA struct sockaddr 
void func(int sockfd) 
{ 
//fonction pour transferer le fichier qui contient les informations et les envoyer au client
  int fp;
   char *file_name = "information.txt";	
   ssize_t read_return;
   char buffer[BUFSIZ];
    fp=open(file_name, O_RDONLY);
 if (fp == -1) {
        perror("open");
        exit(1);
    }
			
 while (1) {
        read_return = read(fp, buffer, BUFSIZ);
        if (read_return == 0)
            break;
        if (read_return == -1) {
            perror("read");
            exit(1);
        }
        if (write(sockfd, buffer, read_return) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
    }
			
        
}
