#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/stat.h>
#define MAX 1024
#define PORT 8080 
#define SA struct sockaddr 
//fonction qui permet de creer un fichier et mettre les information reçu par le serveur puis les afficher
void func(int sockfd) 
{
	 char buffer[BUFSIZ];
      char *file_name = "information_reception.txt";
      int filefd;  ssize_t read_return;
	filefd = open(file_name,O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
       
        if (filefd == -1) {
            perror("open");
            exit(EXIT_FAILURE);
        }
        do {
            read_return = read(sockfd, buffer, BUFSIZ);
               printf("%s",buffer);
               bzero(buffer,sizeof(buffer));
            if (read_return == -1) {
                perror("read");
                exit(EXIT_FAILURE);
            }
            if (write(filefd, buffer, read_return) == -1) {
                perror("write");
                exit(EXIT_FAILURE);
            }
        } while (read_return > 0);
              close(filefd);

} 

