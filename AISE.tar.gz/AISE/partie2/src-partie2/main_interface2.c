#include <stdio.h>	
#include <string.h>	
#include <sys/socket.h>	
#include <arpa/inet.h>	
#include <unistd.h>
#include <errno.h>
#include <stdlib.h> 
#define MAX 1024 
#include "interface2.h"
int main(int argc , char *argv[])
{
	int sock;
	struct sockaddr_in server;
	char message[1000] , server_reply[2000];
	
	//Create socket
	sock = socket(AF_INET , SOCK_STREAM , 0);
	if (sock == -1)
	{
		printf("ne peut pas créer le socket");
	}
	puts("Socket est crée");
	
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_family = AF_INET;
	server.sin_port = htons( 8000 );

	//Connect to remote server
	if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		perror("connexion est échouée");
		return 1;
	}
	
	puts("Connecté\n");
	
     func(sock);
	
	
	close(sock);
	return 0;
}
