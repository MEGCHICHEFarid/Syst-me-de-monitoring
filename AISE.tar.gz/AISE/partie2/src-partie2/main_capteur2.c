#include<stdio.h>
#include<string.h>	
#include<stdlib.h>	
#include<sys/socket.h>
#include<arpa/inet.h>	
#include<unistd.h>	
#include<pthread.h> 
#include <errno.h>
#define MAX 1024
#include "capteur2.h"


int main(int argc , char *argv[])
{
	int socket_desc , client_sock , c , *new_sock;
	struct sockaddr_in server , client;
	
	//creation de socket
	socket_desc = socket(AF_INET , SOCK_STREAM , 0);
	if (socket_desc == -1)
	{
		printf("ne peut pas créer un socket");
	}
	puts("Socket est crée");
	
	//préparation de la structure sockaddr_in 
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons( 8000 );
	
	//Bind
	if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
	{
		
		perror("bind failed. Error");
		return 1;
	}
	puts("bind avec succés");
	
	//Listen
	listen(socket_desc , 3);
	
	
	//Accepter les connexions des clients
	puts("le serveur est en attente des connexion des clients...");
	c = sizeof(struct sockaddr_in);
	while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
	{
		puts("connexion établie");
		
		pthread_t sniffer_thread;
		new_sock = malloc(1);
		*new_sock = client_sock;
		
		if( pthread_create( &sniffer_thread , NULL ,  connection_handler , (void*) new_sock) < 0)
		{
			perror("impossible de créer le thread");
			return 1;
		}
		
		//terminaison des  threads 
		pthread_join( sniffer_thread , NULL);
		puts("thread terminé");
	}
	
	if (client_sock < 0)
	{
		perror("accept échoue");
		return 1;
	}
	

     return 0;
}


