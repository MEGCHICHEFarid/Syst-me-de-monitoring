#ifndef __CUSTOM_H_
#define __CUSTOM_H_
#include <stdlib.h>
#include <pthread.h>
void func(int); 
void *connection_handler(void *);
#endif /* ifndef __CUSTOM_H_ */

 
